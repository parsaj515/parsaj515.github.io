const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Serve static files
app.use(express.static('public'));

// Socket.io connection
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  
  // Handle incoming calls
  socket.on('make-call', (data) => {
    socket.broadcast.emit('incoming-call', {
      caller: data.callerName,
      callerId: socket.id
    });
  });
});

server.listen(3000, () => {
  console.log('Server running on port 3000');
});