from fastapi import FastAPI, APIRouter, WebSocket, WebSocketDisconnect, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone
import asyncio
import base64
from playwright.async_api import async_playwright, Browser, BrowserContext, Page

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI()
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Global state
playwright_instance = None
browser: Optional[Browser] = None
sessions: Dict[str, Dict[str, Any]] = {}

# Models
class SessionCreate(BaseModel):
    session_id: Optional[str] = None

class SessionResponse(BaseModel):
    session_id: str
    status: str
    created_at: str

class NavigateRequest(BaseModel):
    session_id: str
    url: str

class ClickRequest(BaseModel):
    session_id: str
    x: int
    y: int
    button: str = "left"
    click_count: int = 1

class TypeRequest(BaseModel):
    session_id: str
    text: str

class KeyRequest(BaseModel):
    session_id: str
    key: str

class ScrollRequest(BaseModel):
    session_id: str
    delta_x: int = 0
    delta_y: int = 0

class HoverRequest(BaseModel):
    session_id: str
    x: int
    y: int

class DragRequest(BaseModel):
    session_id: str
    start_x: int
    start_y: int
    end_x: int
    end_y: int

class TabRequest(BaseModel):
    session_id: str
    tab_index: Optional[int] = None

class BookmarkCreate(BaseModel):
    session_id: str
    title: str
    url: str
    favicon: Optional[str] = None

class BookmarkResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    session_id: str
    title: str
    url: str
    favicon: Optional[str] = None
    created_at: str

class HistoryEntry(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    session_id: str
    title: str
    url: str
    favicon: Optional[str] = None
    visited_at: str

class ScreenshotRequest(BaseModel):
    session_id: str
    quality: int = 85

# Startup/Shutdown
@app.on_event("startup")
async def startup_event():
    global playwright_instance, browser
    playwright_instance = await async_playwright().start()
    browser = await playwright_instance.chromium.launch(
        headless=True,
        executable_path="/pw-browsers/chromium-1200/chrome-linux/chrome",
        args=['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
    )
    logger.info("Browser initialized")

@app.on_event("shutdown")
async def shutdown_event():
    global playwright_instance, browser, sessions
    for sid in list(sessions.keys()):
        try:
            await sessions[sid]['context'].close()
        except:
            pass
    sessions.clear()
    if browser:
        await browser.close()
    if playwright_instance:
        await playwright_instance.stop()
    client.close()

# Helpers
async def get_session(session_id: str) -> Dict[str, Any]:
    if session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    return sessions[session_id]

async def get_active_page(session_id: str) -> Page:
    session = await get_session(session_id)
    pages = session['context'].pages
    if not pages:
        page = await session['context'].new_page()
        await page.set_viewport_size({"width": 1920, "height": 1080})
        return page
    active_index = session.get('active_tab', 0)
    if active_index >= len(pages):
        active_index = len(pages) - 1
        session['active_tab'] = active_index
    return pages[active_index]

async def capture_screenshot(page: Page, quality: int = 85) -> str:
    try:
        screenshot = await page.screenshot(type='jpeg', quality=quality, full_page=False)
        return base64.b64encode(screenshot).decode('utf-8')
    except Exception as e:
        logger.error(f"Screenshot error: {e}")
        return ""

async def get_page_info(page: Page) -> Dict[str, Any]:
    try:
        return {"title": await page.title(), "url": page.url}
    except:
        return {"title": "New Tab", "url": "about:blank"}

async def get_session_state(session_id: str) -> Dict[str, Any]:
    session = await get_session(session_id)
    page = await get_active_page(session_id)
    screenshot = await capture_screenshot(page)
    info = await get_page_info(page)
    
    tabs = []
    for i, p in enumerate(session['context'].pages):
        tab_info = await get_page_info(p)
        tabs.append({
            "index": i,
            "title": tab_info["title"],
            "url": tab_info["url"],
            "active": i == session.get('active_tab', 0)
        })
    
    return {
        "screenshot": screenshot,
        "url": info["url"],
        "title": info["title"],
        "tabs": tabs,
        "active_tab": session.get('active_tab', 0)
    }

# Session endpoints
@api_router.post("/session/create", response_model=SessionResponse)
async def create_session(data: SessionCreate):
    if not browser:
        raise HTTPException(status_code=500, detail="Browser not initialized")
    
    session_id = data.session_id or str(uuid.uuid4())
    context = await browser.new_context(
        viewport={"width": 1920, "height": 1080},
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        ignore_https_errors=True
    )
    page = await context.new_page()
    await page.goto("about:blank")
    
    sessions[session_id] = {
        "context": context,
        "active_tab": 0,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    return SessionResponse(session_id=session_id, status="active", created_at=sessions[session_id]["created_at"])

@api_router.post("/session/close")
async def close_session(data: SessionCreate):
    if not data.session_id or data.session_id not in sessions:
        raise HTTPException(status_code=404, detail="Session not found")
    await sessions[data.session_id]['context'].close()
    del sessions[data.session_id]
    return {"status": "closed"}

@api_router.get("/session/{session_id}/state")
async def get_state(session_id: str):
    return await get_session_state(session_id)

# Navigation
@api_router.post("/browser/navigate")
async def navigate(data: NavigateRequest):
    page = await get_active_page(data.session_id)
    url = data.url if data.url.startswith(('http://', 'https://', 'about:')) else 'https://' + data.url
    
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        info = await get_page_info(page)
        
        # Add to history
        await db.browser_history.insert_one({
            "id": str(uuid.uuid4()),
            "session_id": data.session_id,
            "title": info["title"],
            "url": url,
            "visited_at": datetime.now(timezone.utc).isoformat()
        })
        
        return await get_session_state(data.session_id)
    except Exception as e:
        logger.error(f"Navigation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/back")
async def go_back(data: SessionCreate):
    page = await get_active_page(data.session_id)
    try:
        await page.go_back(timeout=10000)
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/forward")
async def go_forward(data: SessionCreate):
    page = await get_active_page(data.session_id)
    try:
        await page.go_forward(timeout=10000)
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/refresh")
async def refresh_page(data: SessionCreate):
    page = await get_active_page(data.session_id)
    try:
        await page.reload(timeout=30000)
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Interactions
@api_router.post("/browser/click")
async def click(data: ClickRequest):
    page = await get_active_page(data.session_id)
    try:
        await page.mouse.click(data.x, data.y, button=data.button, click_count=data.click_count)
        await asyncio.sleep(0.15)  # Wait for page reaction
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/type")
async def type_text(data: TypeRequest):
    page = await get_active_page(data.session_id)
    try:
        await page.keyboard.type(data.text, delay=30)
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/press")
async def press_key(data: KeyRequest):
    page = await get_active_page(data.session_id)
    try:
        await page.keyboard.press(data.key)
        await asyncio.sleep(0.1)
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/scroll")
async def scroll(data: ScrollRequest):
    page = await get_active_page(data.session_id)
    try:
        await page.mouse.wheel(data.delta_x, data.delta_y)
        await asyncio.sleep(0.05)
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/hover")
async def hover(data: HoverRequest):
    page = await get_active_page(data.session_id)
    try:
        await page.mouse.move(data.x, data.y)
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/drag")
async def drag(data: DragRequest):
    page = await get_active_page(data.session_id)
    try:
        await page.mouse.move(data.start_x, data.start_y)
        await page.mouse.down()
        await page.mouse.move(data.end_x, data.end_y, steps=10)
        await page.mouse.up()
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Tab Management
@api_router.post("/browser/new-tab")
async def new_tab(data: SessionCreate):
    session = await get_session(data.session_id)
    try:
        page = await session['context'].new_page()
        await page.set_viewport_size({"width": 1920, "height": 1080})
        await page.goto("about:blank")
        session['active_tab'] = len(session['context'].pages) - 1
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/close-tab")
async def close_tab(data: TabRequest):
    session = await get_session(data.session_id)
    pages = session['context'].pages
    
    if len(pages) <= 1:
        raise HTTPException(status_code=400, detail="Cannot close the last tab")
    
    tab_index = data.tab_index if data.tab_index is not None else session.get('active_tab', 0)
    try:
        await pages[tab_index].close()
        if session['active_tab'] >= len(session['context'].pages):
            session['active_tab'] = len(session['context'].pages) - 1
        return await get_session_state(data.session_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@api_router.post("/browser/switch-tab")
async def switch_tab(data: TabRequest):
    session = await get_session(data.session_id)
    pages = session['context'].pages
    
    if data.tab_index is None or data.tab_index < 0 or data.tab_index >= len(pages):
        raise HTTPException(status_code=400, detail="Invalid tab index")
    
    session['active_tab'] = data.tab_index
    return await get_session_state(data.session_id)

# Screenshot on demand
@api_router.post("/browser/screenshot")
async def take_screenshot(data: ScreenshotRequest):
    return await get_session_state(data.session_id)

# Bookmarks
@api_router.post("/bookmarks", response_model=BookmarkResponse)
async def create_bookmark(data: BookmarkCreate):
    bookmark = {
        "id": str(uuid.uuid4()),
        "session_id": data.session_id,
        "title": data.title,
        "url": data.url,
        "favicon": data.favicon,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.bookmarks.insert_one(bookmark)
    return BookmarkResponse(**bookmark)

@api_router.get("/bookmarks/{session_id}", response_model=List[BookmarkResponse])
async def get_bookmarks(session_id: str):
    bookmarks = await db.bookmarks.find({"session_id": session_id}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return [BookmarkResponse(**b) for b in bookmarks]

@api_router.delete("/bookmarks/{bookmark_id}")
async def delete_bookmark(bookmark_id: str):
    result = await db.bookmarks.delete_one({"id": bookmark_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Bookmark not found")
    return {"status": "deleted"}

# History
@api_router.get("/history/{session_id}", response_model=List[HistoryEntry])
async def get_history(session_id: str, limit: int = 50):
    history = await db.browser_history.find({"session_id": session_id}, {"_id": 0}).sort("visited_at", -1).to_list(limit)
    return [HistoryEntry(**h) for h in history]

@api_router.delete("/history/{session_id}")
async def clear_history(session_id: str):
    await db.browser_history.delete_many({"session_id": session_id})
    return {"status": "cleared"}

# Health
@api_router.get("/")
async def root():
    return {"message": "Headless Browser API"}

@api_router.get("/health")
async def health():
    return {"status": "healthy", "browser": browser is not None, "sessions": len(sessions)}

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)
