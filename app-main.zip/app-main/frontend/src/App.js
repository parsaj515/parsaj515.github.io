import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import BrowserView from "./pages/BrowserView";
import { Toaster } from "./components/ui/sonner";

function App() {
  return (
    <div className="App h-screen w-screen overflow-hidden bg-[#050505]">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<BrowserView />} />
        </Routes>
      </BrowserRouter>
      <Toaster 
        position="bottom-right" 
        toastOptions={{
          style: {
            background: '#0A0A0A',
            border: '1px solid rgba(255,255,255,0.1)',
            color: '#fff',
          },
        }}
      />
      <div className="noise-overlay" />
    </div>
  );
}

export default App;
