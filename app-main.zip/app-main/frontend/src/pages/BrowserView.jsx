import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, ArrowRight, RotateCcw, Home, Plus, X, 
  Bookmark, History, Shield, Maximize2, Minimize2,
  Loader2, Globe, Star, Trash2, Clock
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { ScrollArea } from '../components/ui/scroll-area';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../components/ui/tooltip';
import { toast } from 'sonner';
import axios from 'axios';

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const BrowserView = () => {
  const [sessionId, setSessionId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [screenshot, setScreenshot] = useState(null);
  const [currentUrl, setCurrentUrl] = useState('');
  const [urlInput, setUrlInput] = useState('');
  const [pageTitle, setPageTitle] = useState('New Tab');
  const [tabs, setTabs] = useState([]);
  const [activeTab, setActiveTab] = useState(0);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [bookmarks, setBookmarks] = useState([]);
  const [history, setHistory] = useState([]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  const streamRef = useRef(null);
  const pollIntervalRef = useRef(null);

  // Update state from API response
  const updateState = useCallback((data) => {
    if (data.screenshot) setScreenshot(data.screenshot);
    if (data.url !== undefined) {
      setCurrentUrl(data.url);
      setUrlInput(data.url);
    }
    if (data.title) setPageTitle(data.title);
    if (data.tabs) setTabs(data.tabs);
    if (data.active_tab !== undefined) setActiveTab(data.active_tab);
  }, []);

  // Create session on mount
  useEffect(() => {
    createSession();
    return () => {
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, []);

  // Start polling when session is ready
  useEffect(() => {
    if (sessionId) {
      loadBookmarks();
      loadHistory();
      // Poll for updates every 500ms (low frequency, no flashing)
      pollIntervalRef.current = setInterval(() => refreshState(), 500);
    }
    return () => {
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, [sessionId]);

  const createSession = async () => {
    try {
      setIsLoading(true);
      const response = await axios.post(`${API}/session/create`, {});
      setSessionId(response.data.session_id);
      toast.success('Browser ready');
    } catch (error) {
      toast.error('Failed to start browser');
    } finally {
      setIsLoading(false);
    }
  };

  const refreshState = async () => {
    if (!sessionId) return;
    try {
      const response = await axios.get(`${API}/session/${sessionId}/state`);
      updateState(response.data);
    } catch (error) {
      // Silently fail polling
    }
  };

  const loadBookmarks = async () => {
    if (!sessionId) return;
    try {
      const response = await axios.get(`${API}/bookmarks/${sessionId}`);
      setBookmarks(response.data);
    } catch (error) {}
  };

  const loadHistory = async () => {
    if (!sessionId) return;
    try {
      const response = await axios.get(`${API}/history/${sessionId}`);
      setHistory(response.data);
    } catch (error) {}
  };

  // Navigation
  const navigate = async (url) => {
    if (!sessionId || !url) return;
    try {
      setIsLoading(true);
      const response = await axios.post(`${API}/browser/navigate`, { session_id: sessionId, url });
      updateState(response.data);
      loadHistory();
    } catch (error) {
      toast.error('Navigation failed');
    } finally {
      setIsLoading(false);
    }
  };

  const goBack = async () => {
    if (!sessionId) return;
    try {
      const response = await axios.post(`${API}/browser/back`, { session_id: sessionId });
      updateState(response.data);
    } catch (error) {}
  };

  const goForward = async () => {
    if (!sessionId) return;
    try {
      const response = await axios.post(`${API}/browser/forward`, { session_id: sessionId });
      updateState(response.data);
    } catch (error) {}
  };

  const refresh = async () => {
    if (!sessionId) return;
    try {
      setIsLoading(true);
      const response = await axios.post(`${API}/browser/refresh`, { session_id: sessionId });
      updateState(response.data);
    } catch (error) {
      toast.error('Refresh failed');
    } finally {
      setIsLoading(false);
    }
  };

  // Tabs
  const newTab = async () => {
    if (!sessionId) return;
    try {
      const response = await axios.post(`${API}/browser/new-tab`, { session_id: sessionId });
      updateState(response.data);
    } catch (error) {}
  };

  const closeTab = async (index) => {
    if (!sessionId) return;
    try {
      const response = await axios.post(`${API}/browser/close-tab`, { session_id: sessionId, tab_index: index });
      updateState(response.data);
    } catch (error) {}
  };

  const switchTab = async (index) => {
    if (!sessionId) return;
    try {
      const response = await axios.post(`${API}/browser/switch-tab`, { session_id: sessionId, tab_index: index });
      updateState(response.data);
    } catch (error) {}
  };

  // Interactions
  const getCoords = (e) => {
    const img = streamRef.current?.querySelector('img');
    if (!img) return null;
    const rect = img.getBoundingClientRect();
    const x = Math.round((e.clientX - rect.left) * (1920 / rect.width));
    const y = Math.round((e.clientY - rect.top) * (1080 / rect.height));
    if (x < 0 || x > 1920 || y < 0 || y > 1080) return null;
    return { x, y };
  };

  const handleClick = async (e) => {
    if (!sessionId) return;
    const coords = getCoords(e);
    if (!coords) return;
    try {
      const response = await axios.post(`${API}/browser/click`, {
        session_id: sessionId,
        x: coords.x,
        y: coords.y,
        button: 'left',
        click_count: 1
      });
      updateState(response.data);
    } catch (error) {}
  };

  const handleDoubleClick = async (e) => {
    if (!sessionId) return;
    const coords = getCoords(e);
    if (!coords) return;
    try {
      const response = await axios.post(`${API}/browser/click`, {
        session_id: sessionId,
        x: coords.x,
        y: coords.y,
        button: 'left',
        click_count: 2
      });
      updateState(response.data);
    } catch (error) {}
  };

  const handleRightClick = async (e) => {
    e.preventDefault();
    if (!sessionId) return;
    const coords = getCoords(e);
    if (!coords) return;
    try {
      const response = await axios.post(`${API}/browser/click`, {
        session_id: sessionId,
        x: coords.x,
        y: coords.y,
        button: 'right',
        click_count: 1
      });
      updateState(response.data);
    } catch (error) {}
  };

  const handleScroll = async (e) => {
    if (!sessionId) return;
    try {
      const response = await axios.post(`${API}/browser/scroll`, {
        session_id: sessionId,
        delta_x: e.deltaX,
        delta_y: e.deltaY
      });
      updateState(response.data);
    } catch (error) {}
  };

  const handleKeyDown = async (e) => {
    if (!sessionId || e.target.tagName === 'INPUT') return;
    e.preventDefault();
    
    let key = e.key;
    if (e.ctrlKey && key !== 'Control') key = `Control+${key}`;
    if (e.altKey && key !== 'Alt') key = `Alt+${key}`;
    
    try {
      if (key.length === 1 && !e.ctrlKey && !e.altKey) {
        const response = await axios.post(`${API}/browser/type`, { session_id: sessionId, text: key });
        updateState(response.data);
      } else {
        const response = await axios.post(`${API}/browser/press`, { session_id: sessionId, key });
        updateState(response.data);
      }
    } catch (error) {}
  };

  // Bookmarks
  const addBookmark = async () => {
    if (!sessionId || !currentUrl || currentUrl === 'about:blank') return;
    try {
      await axios.post(`${API}/bookmarks`, { session_id: sessionId, title: pageTitle || currentUrl, url: currentUrl });
      loadBookmarks();
      toast.success('Bookmark added');
    } catch (error) {}
  };

  const deleteBookmark = async (id) => {
    try {
      await axios.delete(`${API}/bookmarks/${id}`);
      loadBookmarks();
    } catch (error) {}
  };

  const clearHistory = async () => {
    if (!sessionId) return;
    try {
      await axios.delete(`${API}/history/${sessionId}`);
      setHistory([]);
      toast.success('History cleared');
    } catch (error) {}
  };

  const handleUrlSubmit = (e) => {
    e.preventDefault();
    if (urlInput) navigate(urlInput);
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [sessionId]);

  return (
    <TooltipProvider>
      <div className="flex flex-col h-screen w-screen bg-[#050505] overflow-hidden" data-testid="browser-view">
        {/* Tab Bar */}
        <div className="flex items-center bg-[#0A0A0A] border-b border-white/5" data-testid="tab-bar">
          <div className="flex-1 flex items-center overflow-x-auto px-2 py-1 gap-1">
            <AnimatePresence mode="popLayout">
              {tabs.map((tab, index) => (
                <motion.button
                  key={`tab-${index}`}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-t-lg text-sm transition-colors ${
                    index === activeTab 
                      ? 'bg-[#121212] text-white border-b-2 border-violet-500' 
                      : 'text-gray-400 hover:bg-white/5 hover:text-white'
                  }`}
                  onClick={() => switchTab(index)}
                  data-testid={`tab-${index}`}
                >
                  <Globe className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate max-w-[120px]">{tab.title || 'New Tab'}</span>
                  {tabs.length > 1 && (
                    <span 
                      className="p-0.5 rounded hover:bg-white/10"
                      onClick={(e) => { e.stopPropagation(); closeTab(index); }}
                    >
                      <X className="w-3 h-3" />
                    </span>
                  )}
                </motion.button>
              ))}
            </AnimatePresence>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-white/5" onClick={newTab} data-testid="new-tab-btn">
                  <Plus className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>New Tab</TooltipContent>
            </Tooltip>
          </div>
          
          <div className="flex items-center gap-2 px-4">
            <Shield className="w-4 h-4 text-emerald-500" />
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
        </div>

        {/* URL Bar */}
        <div className="flex items-center gap-2 px-4 py-2 bg-[#0A0A0A] border-b border-white/5" data-testid="url-bar-container">
          <div className="flex items-center gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 p-0" onClick={goBack} data-testid="back-btn">
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Back</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 p-0" onClick={goForward} data-testid="forward-btn">
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Forward</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 p-0" onClick={refresh} data-testid="refresh-btn">
                  {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Refresh</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 p-0" onClick={() => navigate('https://www.google.com')} data-testid="home-btn">
                  <Home className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Home</TooltipContent>
            </Tooltip>
          </div>
          
          <form onSubmit={handleUrlSubmit} className="flex-1 max-w-4xl">
            <Input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="Enter URL..."
              className="bg-[#121212] border-white/10 focus:border-violet-500/50 text-white placeholder-gray-600 font-mono text-sm"
              data-testid="url-input"
            />
          </form>
          
          <div className="flex items-center gap-1">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 p-0" onClick={addBookmark} data-testid="add-bookmark-btn">
                  <Star className={`w-4 h-4 ${bookmarks.some(b => b.url === currentUrl) ? 'fill-yellow-500 text-yellow-500' : ''}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Bookmark</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className={`h-9 w-9 p-0 ${showBookmarks ? 'bg-violet-500/20 text-violet-400' : ''}`}
                  onClick={() => { setShowBookmarks(!showBookmarks); setShowHistory(false); }}
                  data-testid="bookmarks-btn"
                >
                  <Bookmark className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Bookmarks</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className={`h-9 w-9 p-0 ${showHistory ? 'bg-violet-500/20 text-violet-400' : ''}`}
                  onClick={() => { setShowHistory(!showHistory); setShowBookmarks(false); }}
                  data-testid="history-btn"
                >
                  <History className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>History</TooltipContent>
            </Tooltip>
            
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-9 w-9 p-0" onClick={() => setIsFullscreen(!isFullscreen)} data-testid="fullscreen-btn">
                  {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </Button>
              </TooltipTrigger>
              <TooltipContent>{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</TooltipContent>
            </Tooltip>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Browser Stream */}
          <div 
            ref={streamRef}
            className="flex-1 bg-black flex items-center justify-center overflow-hidden"
            onClick={handleClick}
            onDoubleClick={handleDoubleClick}
            onContextMenu={handleRightClick}
            onWheel={handleScroll}
            tabIndex={0}
            data-testid="browser-stream"
          >
            {screenshot ? (
              <img 
                src={`data:image/jpeg;base64,${screenshot}`}
                alt="Browser"
                className="max-w-full max-h-full object-contain select-none"
                draggable={false}
              />
            ) : (
              <div className="flex flex-col items-center justify-center text-gray-500">
                {isLoading ? (
                  <>
                    <Loader2 className="w-12 h-12 animate-spin mb-4 text-violet-500" />
                    <span className="text-sm">Starting browser...</span>
                  </>
                ) : (
                  <>
                    <Globe className="w-16 h-16 mb-4 opacity-30" />
                    <span className="text-sm">Enter a URL to start browsing</span>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <AnimatePresence>
            {(showBookmarks || showHistory) && (
              <motion.div
                initial={{ width: 0, opacity: 0 }}
                animate={{ width: 320, opacity: 1 }}
                exit={{ width: 0, opacity: 0 }}
                className="bg-[#0A0A0A] border-l border-white/5 overflow-hidden"
              >
                <ScrollArea className="h-full">
                  {showBookmarks && (
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">Bookmarks</h3>
                        <Button variant="ghost" size="sm" onClick={() => setShowBookmarks(false)}><X className="w-4 h-4" /></Button>
                      </div>
                      {bookmarks.length === 0 ? (
                        <p className="text-gray-500 text-sm text-center py-8">No bookmarks</p>
                      ) : (
                        <div className="space-y-2">
                          {bookmarks.map((b) => (
                            <div key={b.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 group cursor-pointer" onClick={() => navigate(b.url)}>
                              <Globe className="w-4 h-4 text-gray-500" />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm truncate">{b.title}</p>
                                <p className="text-xs text-gray-500 truncate font-mono">{b.url}</p>
                              </div>
                              <Button variant="ghost" size="sm" className="h-7 w-7 p-0 opacity-0 group-hover:opacity-100" onClick={(e) => { e.stopPropagation(); deleteBookmark(b.id); }}>
                                <Trash2 className="w-3 h-3 text-red-500" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                  
                  {showHistory && (
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">History</h3>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm" onClick={clearHistory} className="text-red-500"><Trash2 className="w-4 h-4" /></Button>
                          <Button variant="ghost" size="sm" onClick={() => setShowHistory(false)}><X className="w-4 h-4" /></Button>
                        </div>
                      </div>
                      {history.length === 0 ? (
                        <p className="text-gray-500 text-sm text-center py-8">No history</p>
                      ) : (
                        <div className="space-y-2">
                          {history.map((h) => (
                            <div key={h.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 cursor-pointer" onClick={() => navigate(h.url)}>
                              <Clock className="w-4 h-4 text-gray-500" />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm truncate">{h.title}</p>
                                <p className="text-xs text-gray-500 truncate font-mono">{h.url}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </ScrollArea>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Status Bar */}
        <div className="flex items-center justify-between px-4 py-1.5 bg-[#0A0A0A] border-t border-white/5 text-xs text-gray-500">
          <span className="font-mono truncate max-w-md">{currentUrl || 'about:blank'}</span>
          <span className="flex items-center gap-2">
            <Shield className="w-3 h-3 text-emerald-500" />
            Isolated Session
          </span>
        </div>
      </div>
    </TooltipProvider>
  );
};

export default BrowserView;
