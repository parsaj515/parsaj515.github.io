#!/usr/bin/env python3
"""
Comprehensive Backend API Testing for Headless Browser Application
Tests all endpoints including session management, navigation, interactions, tabs, bookmarks, and history.
"""

import requests
import sys
import json
import time
from datetime import datetime
from typing import Dict, Any, Optional

class HeadlessBrowserAPITester:
    def __init__(self, base_url="https://browser-control-5.preview.emergentagent.com/api"):
        self.base_url = base_url
        self.session_id = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_results = []
        
    def log_test(self, name: str, success: bool, details: str = "", response_data: Any = None):
        """Log test result"""
        self.tests_run += 1
        if success:
            self.tests_passed += 1
            print(f"✅ {name}: PASSED")
        else:
            print(f"❌ {name}: FAILED - {details}")
        
        self.test_results.append({
            "name": name,
            "success": success,
            "details": details,
            "response_data": response_data
        })
    
    def make_request(self, method: str, endpoint: str, data: Optional[Dict] = None, expected_status: int = 200) -> tuple[bool, Any]:
        """Make HTTP request and return success status and response data"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=headers, timeout=30)
            else:
                return False, f"Unsupported method: {method}"
            
            success = response.status_code == expected_status
            try:
                response_data = response.json()
            except:
                response_data = {"status_code": response.status_code, "text": response.text}
            
            return success, response_data
            
        except requests.exceptions.Timeout:
            return False, "Request timeout"
        except requests.exceptions.ConnectionError:
            return False, "Connection error"
        except Exception as e:
            return False, f"Request error: {str(e)}"
    
    def test_health_check(self):
        """Test basic health endpoints"""
        print("\n🔍 Testing Health Endpoints...")
        
        # Test root endpoint
        success, data = self.make_request('GET', '')
        self.log_test("Root endpoint", success, 
                     "" if success else f"Failed to reach root: {data}")
        
        # Test health endpoint
        success, data = self.make_request('GET', 'health')
        self.log_test("Health check", success, 
                     "" if success else f"Health check failed: {data}")
        
        if success and isinstance(data, dict):
            browser_status = data.get('browser', False)
            self.log_test("Browser initialization", browser_status,
                         "" if browser_status else "Browser not initialized")
    
    def test_session_management(self):
        """Test session creation and management"""
        print("\n🔍 Testing Session Management...")
        
        # Create session
        success, data = self.make_request('POST', 'session/create', {})
        if success and 'session_id' in data:
            self.session_id = data['session_id']
            self.log_test("Session creation", True, f"Session ID: {self.session_id}")
        else:
            self.log_test("Session creation", False, f"Failed to create session: {data}")
            return False
        
        # Get session status
        success, data = self.make_request('GET', f'session/{self.session_id}/status')
        self.log_test("Session status", success,
                     "" if success else f"Failed to get status: {data}")
        
        return True
    
    def test_navigation(self):
        """Test browser navigation"""
        if not self.session_id:
            print("❌ Skipping navigation tests - no session")
            return
        
        print("\n🔍 Testing Navigation...")
        
        # Navigate to Google
        success, data = self.make_request('POST', 'browser/navigate', {
            'session_id': self.session_id,
            'url': 'https://www.google.com'
        })
        self.log_test("Navigate to Google", success,
                     "" if success else f"Navigation failed: {data}")
        
        # Wait for page load
        time.sleep(2)
        
        # Test back navigation
        success, data = self.make_request('POST', 'browser/back', {
            'session_id': self.session_id
        })
        self.log_test("Back navigation", success,
                     "" if success else f"Back failed: {data}")
        
        # Test forward navigation
        success, data = self.make_request('POST', 'browser/forward', {
            'session_id': self.session_id
        })
        self.log_test("Forward navigation", success,
                     "" if success else f"Forward failed: {data}")
        
        # Test refresh
        success, data = self.make_request('POST', 'browser/refresh', {
            'session_id': self.session_id
        })
        self.log_test("Page refresh", success,
                     "" if success else f"Refresh failed: {data}")
    
    def test_interactions(self):
        """Test browser interactions"""
        if not self.session_id:
            print("❌ Skipping interaction tests - no session")
            return
        
        print("\n🔍 Testing Browser Interactions...")
        
        # Test click
        success, data = self.make_request('POST', 'browser/click', {
            'session_id': self.session_id,
            'x': 500,
            'y': 300,
            'button': 'left',
            'click_count': 1
        })
        self.log_test("Click interaction", success,
                     "" if success else f"Click failed: {data}")
        
        # Test type
        success, data = self.make_request('POST', 'browser/type', {
            'session_id': self.session_id,
            'text': 'test search'
        })
        self.log_test("Type interaction", success,
                     "" if success else f"Type failed: {data}")
        
        # Test key press
        success, data = self.make_request('POST', 'browser/press', {
            'session_id': self.session_id,
            'key': 'Enter'
        })
        self.log_test("Key press", success,
                     "" if success else f"Key press failed: {data}")
        
        # Test scroll
        success, data = self.make_request('POST', 'browser/scroll', {
            'session_id': self.session_id,
            'delta_x': 0,
            'delta_y': 100
        })
        self.log_test("Scroll interaction", success,
                     "" if success else f"Scroll failed: {data}")
        
        # Test hover
        success, data = self.make_request('POST', 'browser/hover', {
            'session_id': self.session_id,
            'x': 400,
            'y': 200
        })
        self.log_test("Hover interaction", success,
                     "" if success else f"Hover failed: {data}")
        
        # Test drag
        success, data = self.make_request('POST', 'browser/drag', {
            'session_id': self.session_id,
            'start_x': 100,
            'start_y': 100,
            'end_x': 200,
            'end_y': 200
        })
        self.log_test("Drag interaction", success,
                     "" if success else f"Drag failed: {data}")
    
    def test_tab_management(self):
        """Test tab management"""
        if not self.session_id:
            print("❌ Skipping tab tests - no session")
            return
        
        print("\n🔍 Testing Tab Management...")
        
        # Create new tab
        success, data = self.make_request('POST', 'browser/new-tab', {
            'session_id': self.session_id
        })
        self.log_test("Create new tab", success,
                     "" if success else f"New tab failed: {data}")
        
        # Get tabs list
        success, data = self.make_request('GET', f'browser/{self.session_id}/tabs')
        tab_count = len(data.get('tabs', [])) if success else 0
        self.log_test("Get tabs list", success,
                     f"Found {tab_count} tabs" if success else f"Get tabs failed: {data}")
        
        # Switch to first tab
        success, data = self.make_request('POST', 'browser/switch-tab', {
            'session_id': self.session_id,
            'tab_index': 0
        })
        self.log_test("Switch tab", success,
                     "" if success else f"Switch tab failed: {data}")
        
        # Close tab (only if we have more than 1)
        if tab_count > 1:
            success, data = self.make_request('POST', 'browser/close-tab', {
                'session_id': self.session_id,
                'tab_index': 1
            })
            self.log_test("Close tab", success,
                         "" if success else f"Close tab failed: {data}")
    
    def test_bookmarks(self):
        """Test bookmark functionality"""
        if not self.session_id:
            print("❌ Skipping bookmark tests - no session")
            return
        
        print("\n🔍 Testing Bookmarks...")
        
        # Create bookmark
        success, data = self.make_request('POST', 'bookmarks', {
            'session_id': self.session_id,
            'title': 'Test Bookmark',
            'url': 'https://www.example.com'
        }, expected_status=200)
        
        bookmark_id = None
        if success and 'id' in data:
            bookmark_id = data['id']
            self.log_test("Create bookmark", True, f"Bookmark ID: {bookmark_id}")
        else:
            self.log_test("Create bookmark", False, f"Create failed: {data}")
        
        # Get bookmarks
        success, data = self.make_request('GET', f'bookmarks/{self.session_id}')
        bookmark_count = len(data) if success and isinstance(data, list) else 0
        self.log_test("Get bookmarks", success,
                     f"Found {bookmark_count} bookmarks" if success else f"Get bookmarks failed: {data}")
        
        # Delete bookmark
        if bookmark_id:
            success, data = self.make_request('DELETE', f'bookmarks/{bookmark_id}')
            self.log_test("Delete bookmark", success,
                         "" if success else f"Delete failed: {data}")
    
    def test_history(self):
        """Test history functionality"""
        if not self.session_id:
            print("❌ Skipping history tests - no session")
            return
        
        print("\n🔍 Testing History...")
        
        # Get history
        success, data = self.make_request('GET', f'history/{self.session_id}')
        history_count = len(data) if success and isinstance(data, list) else 0
        self.log_test("Get history", success,
                     f"Found {history_count} history entries" if success else f"Get history failed: {data}")
        
        # Clear history
        success, data = self.make_request('DELETE', f'history/{self.session_id}')
        self.log_test("Clear history", success,
                     "" if success else f"Clear history failed: {data}")
    
    def test_screenshot(self):
        """Test screenshot functionality"""
        if not self.session_id:
            print("❌ Skipping screenshot tests - no session")
            return
        
        print("\n🔍 Testing Screenshot...")
        
        success, data = self.make_request('POST', 'browser/screenshot', {
            'session_id': self.session_id,
            'full_page': False,
            'quality': 80
        })
        
        has_screenshot = success and 'screenshot' in data and data['screenshot']
        self.log_test("Take screenshot", has_screenshot,
                     "" if has_screenshot else f"Screenshot failed: {data}")
    
    def test_advanced_interactions(self):
        """Test advanced interaction features"""
        if not self.session_id:
            print("❌ Skipping advanced interaction tests - no session")
            return
        
        print("\n🔍 Testing Advanced Interactions...")
        
        # Test double click
        success, data = self.make_request('POST', 'browser/double-click', {
            'session_id': self.session_id,
            'x': 500,
            'y': 300,
            'button': 'left'
        })
        self.log_test("Double click", success,
                     "" if success else f"Double click failed: {data}")
        
        # Test select all
        success, data = self.make_request('POST', 'browser/select-all', {
            'session_id': self.session_id
        })
        self.log_test("Select all", success,
                     "" if success else f"Select all failed: {data}")
        
        # Test copy
        success, data = self.make_request('POST', 'browser/copy', {
            'session_id': self.session_id
        })
        self.log_test("Copy", success,
                     "" if success else f"Copy failed: {data}")
        
        # Test paste
        success, data = self.make_request('POST', 'browser/paste', {
            'session_id': self.session_id
        })
        self.log_test("Paste", success,
                     "" if success else f"Paste failed: {data}")
    
    def cleanup_session(self):
        """Clean up test session"""
        if self.session_id:
            print("\n🧹 Cleaning up session...")
            success, data = self.make_request('POST', 'session/close', {
                'session_id': self.session_id
            })
            self.log_test("Session cleanup", success,
                         "" if success else f"Cleanup failed: {data}")
    
    def run_all_tests(self):
        """Run all test suites"""
        print("🚀 Starting Headless Browser API Tests")
        print(f"📡 Testing against: {self.base_url}")
        print("=" * 60)
        
        try:
            # Core functionality tests
            self.test_health_check()
            
            if not self.test_session_management():
                print("❌ Session creation failed - stopping tests")
                return False
            
            # Navigation and interaction tests
            self.test_navigation()
            self.test_interactions()
            self.test_advanced_interactions()
            
            # Feature tests
            self.test_tab_management()
            self.test_bookmarks()
            self.test_history()
            self.test_screenshot()
            
        except Exception as e:
            print(f"❌ Test execution error: {e}")
            return False
        
        finally:
            self.cleanup_session()
        
        # Print summary
        print("\n" + "=" * 60)
        print(f"📊 Test Results: {self.tests_passed}/{self.tests_run} passed")
        success_rate = (self.tests_passed / self.tests_run * 100) if self.tests_run > 0 else 0
        print(f"📈 Success Rate: {success_rate:.1f}%")
        
        if success_rate < 70:
            print("⚠️  Warning: Low success rate - major issues detected")
            return False
        elif success_rate < 90:
            print("⚠️  Warning: Some issues detected")
            return True
        else:
            print("✅ All tests passed successfully!")
            return True

def main():
    """Main test execution"""
    tester = HeadlessBrowserAPITester()
    success = tester.run_all_tests()
    
    # Save detailed results
    with open('/app/backend_test_results.json', 'w') as f:
        json.dump({
            'timestamp': datetime.now().isoformat(),
            'success_rate': (tester.tests_passed / tester.tests_run * 100) if tester.tests_run > 0 else 0,
            'tests_run': tester.tests_run,
            'tests_passed': tester.tests_passed,
            'results': tester.test_results
        }, f, indent=2)
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())